(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_users_page_tsx_dc4b692d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_users_page_tsx_dc4b692d._.js",
  "chunks": [
    "static/chunks/node_modules_@mui_9fb32ead._.js",
    "static/chunks/src_app_admin_users_a9139a62._.js"
  ],
  "source": "dynamic"
});
