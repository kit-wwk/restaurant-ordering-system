(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_d10d5383._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_d10d5383._.js",
  "chunks": [
    "static/chunks/node_modules_1f534dfc._.js",
    "static/chunks/src_6b918c03._.js"
  ],
  "source": "dynamic"
});
