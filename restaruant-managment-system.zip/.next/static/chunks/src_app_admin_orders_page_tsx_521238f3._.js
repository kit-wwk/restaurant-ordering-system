(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_orders_page_tsx_521238f3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_orders_page_tsx_521238f3._.js",
  "chunks": [
    "static/chunks/node_modules_@mui_material_esm_862510bf._.js",
    "static/chunks/node_modules_@mui_x-date-pickers_9ad4c60f._.js",
    "static/chunks/node_modules_@popperjs_core_lib_229f7621._.js",
    "static/chunks/node_modules_049afe72._.js",
    "static/chunks/src_app_admin_orders_page_tsx_1edb586e._.js"
  ],
  "source": "dynamic"
});
