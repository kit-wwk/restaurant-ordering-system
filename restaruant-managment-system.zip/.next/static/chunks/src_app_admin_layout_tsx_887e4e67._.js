(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_layout_tsx_887e4e67._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_layout_tsx_887e4e67._.js",
  "chunks": [
    "static/chunks/_57b596de._.js"
  ],
  "source": "dynamic"
});
