(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_a5dbd67b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_a5dbd67b._.js",
  "chunks": [
    "static/chunks/node_modules_2a94c419._.js",
    "static/chunks/src_6b918c03._.js"
  ],
  "source": "dynamic"
});
