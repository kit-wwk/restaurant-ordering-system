(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_restaurant_page_tsx_dc4b692d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_restaurant_page_tsx_dc4b692d._.js",
  "chunks": [
    "static/chunks/node_modules_a03e2b0c._.js",
    "static/chunks/src_components_admin_RestaurantProfileForm_tsx_7b56611e._.js"
  ],
  "source": "dynamic"
});
