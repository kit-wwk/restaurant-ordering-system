(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_bookings_page_tsx_dc4b692d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_bookings_page_tsx_dc4b692d._.js",
  "chunks": [
    "static/chunks/node_modules_@mui_material_esm_94068808._.js",
    "static/chunks/node_modules_@mui_x-date-pickers_9ad4c60f._.js",
    "static/chunks/node_modules_@popperjs_core_lib_229f7621._.js",
    "static/chunks/node_modules_392b144b._.js",
    "static/chunks/src_app_admin_bookings_page_tsx_1d0d7723._.js"
  ],
  "source": "dynamic"
});
