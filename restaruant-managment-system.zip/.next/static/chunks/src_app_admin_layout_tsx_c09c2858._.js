(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_layout_tsx_c09c2858._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_layout_tsx_c09c2858._.js",
  "chunks": [
    "static/chunks/_14bb4089._.js"
  ],
  "source": "dynamic"
});
