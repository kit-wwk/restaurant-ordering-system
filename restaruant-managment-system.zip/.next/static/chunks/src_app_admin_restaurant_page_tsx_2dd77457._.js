(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_admin_restaurant_page_tsx_2dd77457._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_admin_restaurant_page_tsx_2dd77457._.js",
  "chunks": [
    "static/chunks/node_modules_8c39af5a._.js",
    "static/chunks/src_components_admin_RestaurantProfileForm_tsx_7b56611e._.js"
  ],
  "source": "dynamic"
});
